// config.ts (à garder hors Git !)
export const GITHUB_TOKEN = "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"; // Remplace par ton vrai token
export const GITHUB_REPO = "le-tueur/chatvc"; // Exemple : "le-tueur/chatvc"
export const GITHUB_BRANCH = "main"; // Branche sur laquelle tu veux lire/écrire le JSON

// Optionnel : nom du fichier JSON dans le repo
export const GITHUB_STORAGE_FILE = "chat-storage.json"; // Exemple : "chat-storage.json"
